package tib;

public class MapBean {

	private int LAT;
	private int LNG;
	private int GRIDX;
	private int GRIDY;
	public int getLAT() {
		return LAT;
	}
	public void setLAT(int lAT) {
		LAT = lAT;
	}
	public int getLNG() {
		return LNG;
	}
	public void setLNG(int lNG) {
		LNG = lNG;
	}
	public int getGRIDX() {
		return GRIDX;
	}
	public void setGRIDX(int gRIDX) {
		GRIDX = gRIDX;
	}
	public int getGRIDY() {
		return GRIDY;
	}
	public void setGRIDY(int gRIDY) {
		GRIDY = gRIDY;
	}

}

