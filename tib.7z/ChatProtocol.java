package tib;

public class ChatProtocol {
	public final static String MESSAGE="MESSAGE";
}
